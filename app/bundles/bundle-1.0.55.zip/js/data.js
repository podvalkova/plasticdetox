// Data loading, with the verdicts kept fresh without an App Store release.
//
// The bundle ships a full snapshot so a first launch on aeroplane mode still
// works, and every launch after that asks the site whether there is anything
// newer. Verdicts change for reasons that cannot wait for review: a recall
// lands, a lab result comes back, a brand reformulates. So brand data updates
// over the air on its own clock, separate from the app binary.
//
// Order of preference, best first:
//   1. what we fetched from the site last time, held in local storage
//   2. the snapshot compiled into the bundle
//
// A failed refresh is never an error the user sees. Yesterday's verdicts are
// a good answer; a spinner in a supermarket aisle is not.

import { Index } from "./match.js";

const SITE = "https://plasticdetox.org";
const CACHE_KEY = "pd.data.v1";
const STAMP_KEY = "pd.data.stamp.v1";
// Verdicts are the product, so a stale copy is worse than a slow one. Six
// hours meant a fix pushed at noon was still invisible at six, and the shop
// was assembled from a shelf that had since changed.
const MAX_AGE_MS = 60 * 60 * 1000;   // an hour
const BUILD_KEY = "pd.data.build.v1";

let index = null;
let meta = { source: "bundle", version: null, brands: 0 };

let campaignLinks = {};
let productImages = {};
let articles = [];
let tips = [];
let plan = [];

/**
 * The buy link for an ASIN.
 *
 * A Creator Connections link carries its own campaignId and the campaign's own
 * tag, and only that exact URL credits it. Rebuilding one as
 * /dp/ASIN?tag=plasticdetox-20 looks identical and silently loses the credit,
 * so a campaign URL always wins where we hold one.
 */
export function buyLink(asin) {
  if (!asin) return "";
  return campaignLinks[asin] || `https://www.amazon.com/dp/${asin}?tag=plasticdetox-20`;
}

/**
 * A product photo, where the store holds one.
 *
 * Amazon serves any size off the same id, so the app asks for a small one:
 * a shelf of 150 products should not pull 150 full resolution photographs.
 */
export function productImage(asin, px = 300) {
  const id = asin && productImages[asin];
  if (!id) return "";
  // Some products carry a full URL rather than an Amazon image id, because we
  // host the photo ourselves. The website reads both; so does this now.
  return /^https?:\/\//.test(id)
    ? id
    : `https://m.media-amazon.com/images/I/${id}._AC_SL${px}_.jpg`;
}

/** The articles, newest first. */
export function allArticles() { return articles; }

/**
 * One tip, the same one all day, different tomorrow.
 *
 * Keyed on the day of the year so it needs no storage and no server: everyone
 * opening the app on the same day sees the same tip, and it comes back around
 * in a year. 365 of them, so a leap day repeats the 31st of December rather
 * than showing nothing.
 */
export function tipOfDay(when = new Date()) {
  if (!tips.length) return null;
  return tips[Math.min(dayOfYear(when), tips.length) - 1] || tips[0];
}

/**
 * The day of the year, in the reader's own timezone.
 *
 * This was UTC, which meant the tip turned over at seven in the evening in New
 * York rather than at midnight: you would see tomorrow's tip after dinner and
 * then the same one all through the next morning, which reads as broken.
 *
 * Date.UTC is still the arithmetic, because subtracting local timestamps across
 * a daylight saving boundary is off by an hour and can land on the wrong day.
 * The components going into it are local.
 */
export function dayOfYear(when = new Date()) {
  const start = Date.UTC(when.getFullYear(), 0, 0);
  const today = Date.UTC(when.getFullYear(), when.getMonth(), when.getDate());
  return Math.floor((today - start) / 86400000);
}

/** The 90 day plan, three phases of swaps ordered by exposure. */
export function planPhases({ withLocked = false } = {}) {
  return withLocked ? plan : plan.filter((ph) => !ph.locked);
}

/** The locked rooms, and whether this install has opened them. */
export function lockedPhases() { return plan.filter((ph) => ph.locked); }

async function readBundled(name) {
  const res = await fetch(`./data/${name}.json`, { cache: "force-cache" });
  if (!res.ok) throw new Error(`bundled ${name} missing`);
  return res.json();
}

function readCache() {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || !Array.isArray(parsed.brands) || !parsed.brands.length) return null;
    return parsed;
  } catch {
    return null;
  }
}

function writeCache(payload) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(payload));
    localStorage.setItem(STAMP_KEY, String(Date.now()));
    if (lastBuild) localStorage.setItem(BUILD_KEY, lastBuild);
  } catch {
    // A full quota is not worth failing a lookup over. We simply refetch next
    // launch and keep serving the bundled snapshot in the meantime.
  }
}

function build(payload, source) {
  index = new Index(payload.brands, payload.asins || {}, payload.barcodes || {});
  meta = {
    source,
    version: payload.version || null,
    brands: payload.brands.length,
    fetched: payload.fetched || null,
  };
  return index;
}

/** Load the best data we have, without touching the network. */
/**
 * The three small files that are not the verdict payload.
 *
 * These have to load on every launch, not only on the one where the cache is
 * cold. They used to sit after the `if (cached) return` below, which meant
 * that from the second launch onwards the app had no product images, no
 * articles and no campaign links: the shop was a wall of fallback text, the
 * Learn tab was empty, and Creator Connections links quietly reverted to a
 * plain tag. Small, independent of the brand payload, and cheap to read.
 */
let sidecarsLoaded = false;
let lastBuild = "";
async function sidecars() {
  if (sidecarsLoaded) return;
  sidecarsLoaded = true;
  [campaignLinks, productImages, articles, plan, tips] = await Promise.all([
    readBundled("campaign-links").catch(() => ({})),
    readBundled("product-images").catch(() => ({})),
    readBundled("articles").catch(() => []),
    readBundled("plan").catch(() => []),
    readBundled("tips").catch(() => []),
  ]);
}

export async function load() {
  await sidecars();
  if (index) return index;
  const cached = readCache();
  if (cached) return build(cached, "cache");
  const [brands, asins, barcodes] = await Promise.all([
    readBundled("brand-data"),
    readBundled("asin-map"),
    readBundled("barcodes").catch(() => ({})),
  ]);
  return build({ brands, asins, barcodes }, "bundle");
}

/**
 * Ask the site for newer verdicts. Safe to call on every launch: it returns
 * early unless the cache is stale, and it never throws.
 */
export async function refresh({ force = false, build = "" } = {}) {
  const stamp = Number(localStorage.getItem(STAMP_KEY) || 0);
  // A new app build almost always means new verdicts, and it is the one moment
  // we know for certain that something changed. Coterie was good on the site
  // and careful in the app for hours because the cache had not aged out yet.
  let stale = false;
  try {
    if (build && localStorage.getItem(BUILD_KEY) !== build) stale = true;
  } catch {
    // Unreadable storage just means we fall back to the clock.
  }
  if (!force && !stale && Date.now() - stamp < MAX_AGE_MS) return { skipped: true };
  lastBuild = build || lastBuild;
  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 12000);
    const [brands, asins, barcodes] = await Promise.all([
      fetch(`${SITE}/brand-data.json`, { signal: ctl.signal }).then((r) => r.json()),
      fetch(`${SITE}/app/data/asin-map.json`, { signal: ctl.signal }).then((r) => r.json()).catch(() => null),
      fetch(`${SITE}/app/data/barcodes.json`, { signal: ctl.signal }).then((r) => r.json()).catch(() => null),
    ]);
    clearTimeout(timer);
    if (!Array.isArray(brands) || brands.length < 100) return { skipped: true };

    const current = readCache() || {};
    const payload = {
      brands,
      asins: asins || current.asins || (await readBundled("asin-map")),
      barcodes: barcodes || current.barcodes || {},
      fetched: new Date().toISOString(),
    };
    writeCache(payload);
    build(payload, "fresh");
    return { updated: true, brands: brands.length };
  } catch {
    return { skipped: true };
  }
}

export function status() {
  return meta;
}

export function getIndex() {
  return index;
}
